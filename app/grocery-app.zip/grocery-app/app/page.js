"use client";

import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loadProducts, selectCategories, selectProductError, selectProductItems, selectProductStatus } from "@/store/slices/productsSlice";
import Header from "@/components/Header";
import SearchAndFilters from "@/components/SearchAndFilters";
import ProductGrid from "@/components/ProductGrid";
import CartPanel from "@/components/CartPanel";

export default function Home() {
  const dispatch = useDispatch();
  const status = useSelector(selectProductStatus);
  const error = useSelector(selectProductError);
  const products = useSelector(selectProductItems);
  const categories = useSelector(selectCategories);

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [sortBy, setSortBy] = useState("default");

  useEffect(() => {
    dispatch(loadProducts());
  }, [dispatch]);

  const filtered = useMemo(() => {
    let list = products;

    if (category !== "all") {
      list = list.filter((p) => p.category === category);
    }

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((p) => p.title.toLowerCase().includes(q));
    }

    if (sortBy === "price-asc") {
      list = [...list].sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-desc") {
      list = [...list].sort((a, b) => b.price - a.price);
    }

    return list;
  }, [products, category, search, sortBy]);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <section className="border-b border-line bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <h1 className="max-w-xl font-serif text-3xl font-semibold leading-tight text-ink sm:text-4xl">
            This week&apos;s fresh picks
          </h1>
          <p className="mt-2 max-w-lg text-sm text-ink-soft">
            Search the shelves, build your basket, and watch the discount unlock as your total grows.
          </p>
        </div>
      </section>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr_320px]">
          <SearchAndFilters
            search={search}
            onSearchChange={setSearch}
            categories={categories}
            category={category}
            onCategoryChange={setCategory}
            sortBy={sortBy}
            onSortChange={setSortBy}
            resultCount={filtered.length}
          />

          <ProductGrid
            status={status}
            error={error}
            products={filtered}
            onRetry={() => dispatch(loadProducts())}
          />

          <CartPanel />
        </div>
      </main>

      <footer className="border-t border-line px-4 py-6 text-center text-xs text-ink-soft sm:px-6 lg:px-8">
        Try promo codes FRESH10, MEGA20 (min $100) or FLAT15 (min $40).
      </footer>
    </div>
  );
}
