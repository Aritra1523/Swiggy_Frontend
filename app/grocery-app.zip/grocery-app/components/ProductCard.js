"use client";

import { useDispatch, useSelector } from "react-redux";
import { Minus, Plus, Star } from "lucide-react";
import { addItem, decrementQty, incrementQty, selectCartItems } from "@/store/slices/cartSlice";
import { formatCurrency } from "@/lib/pricing";

export default function ProductCard({ product }) {
  const dispatch = useDispatch();
  const items = useSelector(selectCartItems);
  const inCart = items.find((i) => i.id === product.id);

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-surface shadow-sm transition hover:shadow-md">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-bg">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.thumbnail}
          alt={product.title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
        />
        <span className="absolute left-3 top-3 rounded-full bg-surface/90 px-2.5 py-1 text-[11px] capitalize text-ink-soft shadow-sm">
          {product.category.replace(/-/g, " ")}
        </span>
        <span className="absolute -bottom-3 right-3 rounded-md bg-accent px-2.5 py-1 text-sm font-semibold text-white shadow">
          {formatCurrency(product.price)}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4 pt-5">
        <h3 className="line-clamp-2 text-sm font-medium text-ink" title={product.title}>
          {product.title}
        </h3>

        {typeof product.rating === "number" && (
          <div className="flex items-center gap-1 text-xs text-ink-soft">
            <Star size={13} className="fill-highlight text-highlight" />
            {product.rating.toFixed(1)}
          </div>
        )}

        <div className="mt-auto pt-3">
          {!inCart ? (
            <button
              type="button"
              onClick={() => dispatch(addItem(product))}
              className="w-full rounded-lg bg-primary py-2 text-sm font-medium text-white transition hover:bg-primary-dark"
            >
              Add to basket
            </button>
          ) : (
            <div className="flex items-center justify-between rounded-lg border border-primary/40 bg-primary/5 px-2 py-1.5">
              <button
                type="button"
                aria-label={`Remove one ${product.title}`}
                onClick={() => dispatch(decrementQty(product.id))}
                className="flex h-7 w-7 items-center justify-center rounded-md text-primary transition hover:bg-primary/15"
              >
                <Minus size={15} />
              </button>
              <span className="text-sm font-semibold text-ink">{inCart.quantity}</span>
              <button
                type="button"
                aria-label={`Add one more ${product.title}`}
                onClick={() => dispatch(incrementQty(product.id))}
                className="flex h-7 w-7 items-center justify-center rounded-md text-primary transition hover:bg-primary/15"
              >
                <Plus size={15} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
