"use client";

import { useDispatch } from "react-redux";
import { Minus, Plus, Trash2 } from "lucide-react";
import { decrementQty, incrementQty, removeItem } from "@/store/slices/cartSlice";
import { formatCurrency } from "@/lib/pricing";

export default function CartItem({ item }) {
  const dispatch = useDispatch();

  return (
    <div className="flex items-center gap-3 py-3">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={item.thumbnail}
        alt={item.title}
        className="h-12 w-12 shrink-0 rounded-lg border border-line object-cover"
      />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-ink" title={item.title}>
          {item.title}
        </p>
        <p className="text-xs text-ink-soft">{formatCurrency(item.price)} each</p>
      </div>

      <div className="flex items-center gap-1 rounded-lg border border-line px-1 py-1">
        <button
          type="button"
          aria-label={`Remove one ${item.title}`}
          onClick={() => dispatch(decrementQty(item.id))}
          className="flex h-6 w-6 items-center justify-center rounded text-ink-soft transition hover:bg-bg hover:text-ink"
        >
          <Minus size={13} />
        </button>
        <span className="w-5 text-center text-xs font-semibold text-ink">{item.quantity}</span>
        <button
          type="button"
          aria-label={`Add one more ${item.title}`}
          onClick={() => dispatch(incrementQty(item.id))}
          className="flex h-6 w-6 items-center justify-center rounded text-ink-soft transition hover:bg-bg hover:text-ink"
        >
          <Plus size={13} />
        </button>
      </div>

      <button
        type="button"
        aria-label={`Remove ${item.title} from basket`}
        onClick={() => dispatch(removeItem(item.id))}
        className="shrink-0 text-ink-soft transition hover:text-accent"
      >
        <Trash2 size={16} />
      </button>
    </div>
  );
}
