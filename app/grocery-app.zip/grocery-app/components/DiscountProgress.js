"use client";

import { getNextTier, getTierDiscountPercent, formatCurrency } from "@/lib/pricing";

export default function DiscountProgress({ subtotal }) {
  const currentPercent = getTierDiscountPercent(subtotal);
  const next = getNextTier(subtotal);

  if (!next) {
    return (
      <div className="rounded-lg bg-highlight/15 px-3 py-2 text-xs font-medium text-primary-dark">
        {currentPercent}% basket discount unlocked — nice haul.
      </div>
    );
  }

  const progress = Math.min(100, Math.round((subtotal / next.threshold) * 100));
  const remaining = Math.max(0, next.threshold - subtotal);

  return (
    <div className="rounded-lg border border-line bg-bg px-3 py-2.5">
      <p className="text-xs text-ink-soft">
        {subtotal === 0
          ? `Spend ${formatCurrency(next.threshold)} to unlock ${next.percent}% off.`
          : `Add ${formatCurrency(remaining)} more to unlock ${next.percent}% off${
              currentPercent ? ` (up from ${currentPercent}%)` : ""
            }.`}
      </p>
      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-line">
        <div
          className="h-full rounded-full bg-highlight transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
