"use client";

import { useDispatch, useSelector } from "react-redux";
import { X } from "lucide-react";
import {
  applyCoupon,
  clearCoupon,
  selectAppliedCoupon,
  selectCouponInput,
  selectCouponMessage,
  setCouponInput,
} from "@/store/slices/cartSlice";

export default function CouponBox() {
  const dispatch = useDispatch();
  const couponInput = useSelector(selectCouponInput);
  const appliedCoupon = useSelector(selectAppliedCoupon);
  const message = useSelector(selectCouponMessage);

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(applyCoupon());
  };

  return (
    <div>
      {appliedCoupon ? (
        <div className="flex items-center justify-between rounded-lg border border-primary/40 bg-primary/5 px-3 py-2">
          <div>
            <p className="text-sm font-medium text-primary-dark">{appliedCoupon.code}</p>
            <p className="text-xs text-ink-soft">{appliedCoupon.label}</p>
          </div>
          <button
            type="button"
            onClick={() => dispatch(clearCoupon())}
            aria-label="Remove coupon"
            className="rounded-full p-1 text-ink-soft transition hover:bg-line/60 hover:text-ink"
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={couponInput}
            onChange={(e) => dispatch(setCouponInput(e.target.value))}
            placeholder="Promo code"
            className="min-w-0 flex-1 rounded-lg border border-line bg-bg px-3 py-2 text-sm uppercase tracking-wide text-ink placeholder:normal-case placeholder:text-ink-soft/70 focus:border-primary"
          />
          <button
            type="submit"
            className="shrink-0 rounded-lg border border-primary px-3 py-2 text-sm font-medium text-primary transition hover:bg-primary hover:text-white"
          >
            Apply
          </button>
        </form>
      )}

      {message && (
        <p className={`mt-2 text-xs ${message.type === "success" ? "text-primary-dark" : "text-accent"}`}>
          {message.text}
        </p>
      )}
    </div>
  );
}
