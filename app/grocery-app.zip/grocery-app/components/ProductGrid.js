"use client";

import ProductCard from "./ProductCard";

function SkeletonCard() {
  return (
    <div className="animate-pulse overflow-hidden rounded-2xl border border-line bg-surface shadow-sm">
      <div className="aspect-[4/3] w-full bg-line/50" />
      <div className="space-y-2 p-4">
        <div className="h-3 w-3/4 rounded bg-line/60" />
        <div className="h-3 w-1/2 rounded bg-line/50" />
        <div className="mt-3 h-8 w-full rounded-lg bg-line/40" />
      </div>
    </div>
  );
}

export default function ProductGrid({ status, error, products, onRetry }) {
  if (status === "loading" || status === "idle") {
    return (
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    );
  }

  if (status === "failed") {
    return (
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-line bg-surface p-10 text-center">
        <p className="text-sm text-ink">Couldn&apos;t load the catalog: {error}</p>
        <button
          type="button"
          onClick={onRetry}
          className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary-dark"
        >
          Try again
        </button>
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="rounded-2xl border border-line bg-surface p-10 text-center text-sm text-ink-soft">
        No items match your search. Try a different keyword or category.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
