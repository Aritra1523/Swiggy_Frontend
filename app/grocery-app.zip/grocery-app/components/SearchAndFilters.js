"use client";

import { Search } from "lucide-react";

export default function SearchAndFilters({
  search,
  onSearchChange,
  categories,
  category,
  onCategoryChange,
  sortBy,
  onSortChange,
  resultCount,
}) {
  return (
    <aside className="lg:sticky lg:top-24 lg:self-start">
      <div className="rounded-2xl border border-line bg-surface p-5 shadow-sm">
        <label className="block text-sm font-medium text-ink" htmlFor="search">
          Find an item
        </label>
        <div className="relative mt-2">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-soft" />
          <input
            id="search"
            type="text"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Try 'bread' or 'apples'"
            className="w-full rounded-lg border border-line bg-bg py-2 pl-9 pr-3 text-sm text-ink placeholder:text-ink-soft/70 focus:border-primary"
          />
        </div>

        <div className="mt-5">
          <label className="block text-sm font-medium text-ink" htmlFor="category">
            Category
          </label>
          <select
            id="category"
            value={category}
            onChange={(e) => onCategoryChange(e.target.value)}
            className="mt-2 w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm text-ink focus:border-primary"
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c.replace(/-/g, " ")}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-5">
          <label className="block text-sm font-medium text-ink" htmlFor="sort">
            Sort by
          </label>
          <select
            id="sort"
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
            className="mt-2 w-full rounded-lg border border-line bg-bg px-3 py-2 text-sm text-ink focus:border-primary"
          >
            <option value="default">Featured</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
          </select>
        </div>

        <p className="mt-5 border-t border-line pt-4 text-xs text-ink-soft">
          {resultCount} item{resultCount === 1 ? "" : "s"} found
        </p>
      </div>
    </aside>
  );
}
