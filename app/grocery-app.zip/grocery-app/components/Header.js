"use client";

import { useSelector } from "react-redux";
import { ShoppingBasket } from "lucide-react";
import { selectCartCount, selectSubtotal } from "@/store/slices/cartSlice";
import { formatCurrency } from "@/lib/pricing";

export default function Header() {
  const count = useSelector(selectCartCount);
  const subtotal = useSelector(selectSubtotal);

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <div>
          <p className="font-serif text-2xl font-semibold leading-none text-ink">Field &amp; Pantry</p>
          <p className="mt-1 text-xs text-ink-soft">Fresh picks, priced fairly.</p>
        </div>

        <a
          href="#basket"
          className="flex items-center gap-3 rounded-full border border-line bg-surface px-4 py-2 shadow-sm transition hover:border-primary"
        >
          <span className="relative">
            <ShoppingBasket size={20} className="text-primary" strokeWidth={1.75} />
            {count > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-semibold text-white">
                {count}
              </span>
            )}
          </span>
          <span className="hidden text-sm text-ink sm:inline">
            {count === 0 ? "Basket is empty" : formatCurrency(subtotal)}
          </span>
        </a>
      </div>
    </header>
  );
}
