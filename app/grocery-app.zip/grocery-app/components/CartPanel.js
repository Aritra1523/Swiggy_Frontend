"use client";

import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Undo2, ShoppingBasket } from "lucide-react";
import {
  clearCart,
  selectCanUndo,
  selectCartItems,
  selectLastActionLabel,
  selectSubtotal,
  undoLast,
} from "@/store/slices/cartSlice";
import { computePricing, formatCurrency } from "@/lib/pricing";
import CartItem from "./CartItem";
import CouponBox from "./CouponBox";
import DiscountProgress from "./DiscountProgress";

export default function CartPanel() {
  const dispatch = useDispatch();
  const items = useSelector(selectCartItems);
  const subtotal = useSelector(selectSubtotal);
  const canUndo = useSelector(selectCanUndo);
  const lastActionLabel = useSelector(selectLastActionLabel);
  const appliedCoupon = useSelector((state) => state.cart.appliedCoupon);
  const [checkedOut, setCheckedOut] = useState(false);

  const pricing = computePricing(subtotal, appliedCoupon);

  return (
    <section id="basket" className="lg:sticky lg:top-24 lg:self-start">
      <div className="flex max-h-[calc(100vh-7rem)] flex-col rounded-2xl border border-line bg-surface shadow-sm">
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <div className="flex items-center gap-2">
            <ShoppingBasket size={18} className="text-primary" />
            <h2 className="font-serif text-lg font-semibold text-ink">Your basket</h2>
          </div>
          <button
            type="button"
            disabled={!canUndo}
            onClick={() => dispatch(undoLast())}
            title={lastActionLabel ? `Undo: ${lastActionLabel}` : "Nothing to undo"}
            className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-primary transition enabled:hover:bg-primary/10 disabled:cursor-not-allowed disabled:text-ink-soft/50"
          >
            <Undo2 size={14} />
            Undo
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-1 px-5 py-10 text-center">
            <p className="text-sm text-ink">Your basket is empty.</p>
            <p className="text-xs text-ink-soft">Add items from the catalog to see them here.</p>
          </div>
        ) : (
          <div className="basket-scroll flex-1 divide-y divide-line overflow-y-auto px-5">
            {items.map((item) => (
              <CartItem key={item.id} item={item} />
            ))}
          </div>
        )}

        <div className="space-y-4 border-t border-line px-5 py-4">
          <DiscountProgress subtotal={subtotal} />

          <CouponBox />

          <dl className="space-y-1.5 text-sm">
            <div className="flex justify-between text-ink-soft">
              <dt>Subtotal</dt>
              <dd>{formatCurrency(subtotal)}</dd>
            </div>
            {pricing.totalDiscount > 0 && (
              <div className="flex justify-between text-accent">
                <dt>
                  Discount
                  {pricing.effectivePercent > 0 ? ` (${pricing.effectivePercent}%)` : ""}
                </dt>
                <dd>-{formatCurrency(pricing.totalDiscount)}</dd>
              </div>
            )}
            <div className="flex justify-between border-t border-line pt-1.5 text-base font-semibold text-ink">
              <dt>Total</dt>
              <dd>{formatCurrency(pricing.total)}</dd>
            </div>
          </dl>

          <div className="flex gap-2">
            <button
              type="button"
              disabled={items.length === 0}
              onClick={() => dispatch(clearCart())}
              className="rounded-lg border border-line px-3 py-2 text-sm text-ink-soft transition enabled:hover:border-accent enabled:hover:text-accent disabled:cursor-not-allowed disabled:opacity-50"
            >
              Clear
            </button>
            <button
              type="button"
              disabled={items.length === 0}
              onClick={() => setCheckedOut(true)}
              className="flex-1 rounded-lg bg-accent py-2 text-sm font-semibold text-white transition enabled:hover:bg-accent-dark disabled:cursor-not-allowed disabled:opacity-50"
            >
              Checkout
            </button>
          </div>

          {checkedOut && (
            <p className="text-center text-xs text-primary-dark">
              This is a demo — no order was placed.{" "}
              <button type="button" className="underline" onClick={() => setCheckedOut(false)}>
                Dismiss
              </button>
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
